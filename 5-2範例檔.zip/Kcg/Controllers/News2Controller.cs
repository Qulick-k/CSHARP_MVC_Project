﻿using Kcg.Dtos;
using Kcg.Models;
using Microsoft.AspNetCore.Mvc;

namespace Kcg.Controllers
{
    public class News2Controller : Controller
    {
        private readonly KcgContext _context;

        public News2Controller(KcgContext context)
        {
            _context = context;
        }

        public IActionResult Index(string keyword)
        {
            var result = from a in _context.News
                         join b in _context.Department on a.DepartmentId equals b.DepartmentId
                         join c in _context.Employee on a.UpdateEmployeeId equals c.EmployeeId
                         select new NewsDto
                         {
                             Click = a.Click,
                             Enable = a.Enable,
                             EndDateTime = a.EndDateTime,
                             NewsId = a.NewsId,
                             StartDateTime = a.StartDateTime,
                             Title = a.Title,
                             UpdateDateTime = a.UpdateDateTime,
                             UpdateEmployeeName = c.Name,
                             DepartmentName = b.Name
                         };

            if (!string.IsNullOrEmpty(keyword))
            {
                result = result.Where(x => x.Title.Contains(keyword));
            }

            return View(result.ToList());
        }
    }
}
